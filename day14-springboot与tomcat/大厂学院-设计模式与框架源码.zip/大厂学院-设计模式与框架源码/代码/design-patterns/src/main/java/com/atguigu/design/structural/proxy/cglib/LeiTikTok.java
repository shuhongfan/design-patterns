package com.atguigu.design.structural.proxy.cglib;


/**
 * Subject  主体
 *
 *
 */
public class LeiTikTok  {

    public void tiktokHaha() {
        System.out.println("雷丰阳，tiktok.... haha....");
    }
}
