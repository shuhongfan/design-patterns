package com.atguigu.design.structural.proxy.dynamic;

public interface SellTikTok {

    void sell();
}
