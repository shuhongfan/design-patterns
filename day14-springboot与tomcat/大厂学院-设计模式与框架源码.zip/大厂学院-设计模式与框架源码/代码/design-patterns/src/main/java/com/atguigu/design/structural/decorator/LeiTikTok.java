package com.atguigu.design.structural.decorator;

public class LeiTikTok implements ManTikTok{
    @Override
    public void tiktok() {
        System.out.println("雷丰阳，tiktok.... ");
    }
}
