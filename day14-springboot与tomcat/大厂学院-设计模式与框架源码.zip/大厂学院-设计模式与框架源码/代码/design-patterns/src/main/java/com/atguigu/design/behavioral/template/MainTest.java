package com.atguigu.design.behavioral.template;

public class MainTest {

    public static void main(String[] args) {

        AutoCookMachine cookMachine = new AutoCookMachine();

        cookMachine.cook();

    }
}
