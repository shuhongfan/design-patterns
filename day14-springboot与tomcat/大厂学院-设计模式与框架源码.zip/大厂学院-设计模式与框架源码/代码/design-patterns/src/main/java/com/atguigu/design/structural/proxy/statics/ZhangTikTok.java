package com.atguigu.design.structural.proxy.statics;

public class ZhangTikTok implements ManTikTok {
    @Override
    public void tiktok() {
        System.out.println("张三，tiktok.... ");
    }
}
