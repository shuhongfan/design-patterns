package com.atguigu.design.structural.decorator;


/**
 * 抽象构建
 */
public  interface ManTikTok {
   void tiktok();
}
