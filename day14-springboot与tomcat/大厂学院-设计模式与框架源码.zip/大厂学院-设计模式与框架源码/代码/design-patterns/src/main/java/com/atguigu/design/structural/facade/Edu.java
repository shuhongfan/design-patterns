package com.atguigu.design.structural.facade;

public class Edu {

    public void assignSchool(String name){
        System.out.println(name+"，你的孩子明天去 硅谷大学附属幼儿园 报道......");
    }
}
