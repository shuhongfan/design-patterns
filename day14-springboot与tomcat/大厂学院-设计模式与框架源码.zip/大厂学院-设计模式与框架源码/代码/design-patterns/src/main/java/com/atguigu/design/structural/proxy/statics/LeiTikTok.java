package com.atguigu.design.structural.proxy.statics;


/**
 * Subject  主体
 *
 *
 */
public class LeiTikTok implements ManTikTok {
    @Override
    public void tiktok() {
        System.out.println("雷丰阳，tiktok.... ");
    }
}
