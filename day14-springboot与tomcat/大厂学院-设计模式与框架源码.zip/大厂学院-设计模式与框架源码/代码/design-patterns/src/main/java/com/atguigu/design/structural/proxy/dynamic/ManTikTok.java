package com.atguigu.design.structural.proxy.dynamic;

public  interface ManTikTok {
   void tiktok();
}
