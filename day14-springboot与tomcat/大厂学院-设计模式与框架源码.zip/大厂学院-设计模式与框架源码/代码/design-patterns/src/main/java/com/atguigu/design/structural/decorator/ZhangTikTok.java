package com.atguigu.design.structural.decorator;

public class ZhangTikTok implements ManTikTok{
    @Override
    public void tiktok() {
        System.out.println("张三，tiktok.... ");
    }
}
