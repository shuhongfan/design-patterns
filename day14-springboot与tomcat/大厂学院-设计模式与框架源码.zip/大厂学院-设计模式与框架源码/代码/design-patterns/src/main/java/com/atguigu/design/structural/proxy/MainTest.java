package com.atguigu.design.structural.proxy;


import com.atguigu.design.structural.proxy.dynamic.LeiTikTok;
import net.sf.cglib.proxy.Enhancer;

/**
 * 代理模式进行tiktok；
 * 客户----联系----宋喆---代理---宝强
 * 大家----联系----硅谷萌萌----代理----我
 *
 *
 * 1）、静态代理
 */
public class MainTest {

    public static void main(String[] args) {

    }
}
