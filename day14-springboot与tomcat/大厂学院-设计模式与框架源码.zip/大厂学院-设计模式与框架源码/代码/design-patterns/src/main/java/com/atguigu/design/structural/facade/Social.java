package com.atguigu.design.structural.facade;

public class Social {

    public void handleSocial(String name){
        System.out.println(name+"，你的社保关系已经转移....");
    }
}
