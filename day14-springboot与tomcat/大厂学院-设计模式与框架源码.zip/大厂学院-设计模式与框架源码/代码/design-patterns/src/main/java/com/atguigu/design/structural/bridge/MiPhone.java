package com.atguigu.design.structural.bridge;

public class MiPhone extends AbstractPhone{
    @Override
    String getPhone() {
        return "小米：";
    }
}
