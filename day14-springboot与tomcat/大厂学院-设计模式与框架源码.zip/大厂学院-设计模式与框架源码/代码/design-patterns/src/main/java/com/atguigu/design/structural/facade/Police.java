package com.atguigu.design.structural.facade;

public class Police {

    public void resgister(String name){
        System.out.println(name + "已办理落户");
    }
}
