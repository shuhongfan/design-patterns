package com.atguigu.design.behavioral.iterator;

public class MaYuCheng extends BeautifulMan{



}
