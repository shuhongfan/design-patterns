package com.atguigu.design.structural.bridge;

public class StudentSale extends AbstractSale{
    public StudentSale(String type, Integer price) {
        super(type, price);
    }
}
