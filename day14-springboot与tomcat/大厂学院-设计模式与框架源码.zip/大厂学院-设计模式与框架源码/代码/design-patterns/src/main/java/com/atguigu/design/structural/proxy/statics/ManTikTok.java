package com.atguigu.design.structural.proxy.statics;

/**
 * 抽象主体。被代理角色能干什么
 */
public  interface ManTikTok {
   void tiktok();
}
